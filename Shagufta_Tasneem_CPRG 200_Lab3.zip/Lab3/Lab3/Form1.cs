﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Starts the application
            InitializeComponent();
        }

        //Exception code when pressing save button
        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

            try
            {
                this.Validate();
                this.productsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.northwindDataSet);
            }

            //Give error message when it field is null
            catch (NoNullAllowedException ex)
            {
                // MessageBox.Show("Error " + ":" + ex.Message + "Field Entry Required" );
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }

            //Delete Exception 
            // Give error when delete a record and save it 
            catch (SqlException ex)
            {

                System.Windows.Forms.MessageBox.Show(" Data Record will be Deleted");


                //// MessageBox.Show("Error " + ":" + ex.Message + "Field Entry Required" );
                //System.Windows.Forms.MessageBox.Show(ex.Message);

            }

        }



        //Loads the form   
        private void Form1_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'northwindDataSet.Categories' table. You can move, or remove it, as needed.
            this.categoriesTableAdapter.Fill(this.northwindDataSet.Categories);
            // TODO: This line of code loads data into the 'northwindDataSet.Suppliers' table. You can move, or remove it, as needed.
            this.suppliersTableAdapter.Fill(this.northwindDataSet.Suppliers);
            // TODO: This line of code loads data into the 'northwindDataSet.Order_Details' table. You can move, or remove it, as needed.
            this.order_DetailsTableAdapter.Fill(this.northwindDataSet.Order_Details);
            // TODO: This line of code loads data into the 'northwindDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.northwindDataSet.Products);

        }

        private void productsBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        //private void productsBindingSource_BindingComplete(object sender, BindingCompleteEventArgs e)
        //{
        //    try
        //    {
        //        this.Validate();
        //        //this.productsBindingSource.EndEdit();
        //        this.tableAdapterManager.UpdateAll(this.northwindDataSet);

        //    }
        //    catch (SqlException ex)
        //    {

        //        System.Windows.Forms.MessageBox.Show(" Data Record will be Deleted");


        //        //// MessageBox.Show("Error " + ":" + ex.Message + "Field Entry Required" );
        //        //System.Windows.Forms.MessageBox.Show(ex.Message);

        //    }
        //}
    }
}

